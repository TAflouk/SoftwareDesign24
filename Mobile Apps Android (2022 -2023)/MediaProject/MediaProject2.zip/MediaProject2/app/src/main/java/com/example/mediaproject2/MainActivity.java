package com.example.mediaproject2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.collection.CircularArray;

import android.content.Context;
import android.media.AudioDeviceCallback;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private AudioManager audioManager;
    private TextView songDetails;
    private TextView trackInfo;


    ArrayList<Integer> songs = new ArrayList<>();


    private ImageView imageView;

    private SeekBar seek_bar;
    int currentIndex = 0;


    private Runnable trackLengthUpdate = new Runnable() {
        @Override
        public void run() {
            if (mediaPlayer != null) {
                int duration = mediaPlayer.getCurrentPosition();
                String timeString = String.format("%2d:%2d:%2d",
                        TimeUnit.MILLISECONDS.toHours(duration),
                        TimeUnit.MILLISECONDS.toMinutes(duration),
                        TimeUnit.MILLISECONDS.toSeconds(duration) % 60);
                trackInfo.setText(timeString);
                seek_bar.setProgress(duration);
                handler.postDelayed(this, 500);
                seek_bar.setEnabled(true);

            }

        }
    };
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        trackInfo = findViewById(R.id.track_info);
        seek_bar = findViewById(R.id.seek_bar);
        imageView = findViewById(R.id.image);
        songDetails = findViewById(R.id.songDetails);
        songs.add(0, R.raw.adele__hello);
        songs.add(1, R.raw.burno_mars);
        songs.add(2, R.raw.hello_baby_alma);
        songs.add(3, R.raw.ragbone_man_human);
        songs.add(4, R.raw.sia_unstoppable);


        seek_bar.setMin(0);
        handler = new Handler();

        seek_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                mediaPlayer.seekTo(i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                handler.removeCallbacks(trackLengthUpdate);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                handler.postDelayed(trackLengthUpdate, 500);
            }
        });
        seek_bar.setEnabled(false);

        audioManager = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);


    }



    @Override
    protected void onStart() {
        super.onStart();
        if (mediaPlayer == null) {

            mediaPlayer = MediaPlayer.create(getApplicationContext(), songs.get(currentIndex));
        }
        songDetails();
        mediaPlayer.start();
        handler.postDelayed(trackLengthUpdate, 500);
        seek_bar.setMax(mediaPlayer.getDuration());

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mediaPlayer != null) {
            mediaPlayer.pause();
        }
    }


    public void playPressed(View view) {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, songs.get(currentIndex));

        }
        mediaPlayer.start();
    }

    public void pausePressed(View view) {
        if (mediaPlayer != null) {
            Button btn = (Button) view;
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                btn.setText("Pause");
            } else {
                mediaPlayer.start();
                btn.setText("Pause");
            }

            mediaPlayer.pause();
        }
    }
//    public void pausePressed(View view) {
//        if (mediaPlayer != null) {
//            Button btn = (Button) view;
//            if (mediaPlayer.isPlaying()) {
//                mediaPlayer.pause();
//                btn.setText("Play");  // Change the button text to "Play" when paused
//                seek_bar.setEnabled(false);  // Freeze the SeekBar
//            } else {
//                mediaPlayer.start();
//                btn.setText("Pause");
//                seek_bar.setEnabled(true);  // Enable the SeekBar when playing
//            }
//        }
//    }



    public void forwardPressed(View view) {
        if (mediaPlayer != null) {
            // get the current track position
            int position = mediaPlayer.getCurrentPosition();
            int nextPosition = position + 5000;
            if(nextPosition <= mediaPlayer.getDuration() ){
                // increase the position
                mediaPlayer.seekTo(nextPosition);
            }
        }
    }
    public void mutePressed(View view) {
        if (mediaPlayer != null) {
            AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (audioManager != null) {
                boolean isMute = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0;
                if (isMute) {
                    // Unmute
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 50, 0); // Adjust volume level as needed
                    ((Button) view).setText("Mute");
                } else {
                    // Mute
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
                    ((Button) view).setText("Unmute");
                }
            }
        }
    }
    public void RewindPressed(View view) {
        if (mediaPlayer != null) {
            //get the current track position
            int position = mediaPlayer.getCurrentPosition();
            int nextPosition = position - 5000;
            if (nextPosition > 0) {
                //decrease the position
                mediaPlayer.seekTo(nextPosition);
            }
        }
    }

    public void previousSongPressed(View view) {
        if (mediaPlayer != null) {
            if (currentIndex > 0) {
                currentIndex--;
            } else {
                currentIndex = songs.size() - 1;
            }
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer = MediaPlayer.create(this, songs.get(currentIndex));
            mediaPlayer.start();
            songDetails();
        }
    }

    public void nextSongPressed(View view) {
        if (mediaPlayer != null) {
            if (currentIndex < songs.size() - 1) {
                currentIndex++;
            } else {
                currentIndex = 0;
            }
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer = MediaPlayer.create(this, songs.get(currentIndex));
            mediaPlayer.start();
            songDetails();


        }
    }

    private void songDetails() {
        switch (currentIndex) {
            case 0:
                imageView.setImageResource(R.drawable.adele);
                songDetails.setText("Adele - Hello");
                break;
            case 1:
                imageView.setImageResource(R.drawable.burnomars);
                songDetails.setText("Bruno Mars - All That");
                break;
            case 2:
                imageView.setImageResource(R.drawable.almacogan);
                songDetails.setText("Alma Cogan - Creative Mind");
                break;
            case 3:
                imageView.setImageResource(R.drawable.ragnboneman);
                songDetails.setText("Rag'n'Bone Man - Human");
                break;
            case 4:
                imageView.setImageResource(R.drawable.sia);
                songDetails.setText("Sia - Unstoppable");
                break;
            default:
                // Handle the case where currentIndex is out of bounds
                break;
        }
    }


    public void VolumeDownPressed(View view) {
        if (mediaPlayer != null) {
            audioManager.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_PLAY_SOUND);
        }
    }

    public void VolumeUpPressed(View view) {
        if (mediaPlayer != null) {
            audioManager.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_PLAY_SOUND);
        }
    }
}
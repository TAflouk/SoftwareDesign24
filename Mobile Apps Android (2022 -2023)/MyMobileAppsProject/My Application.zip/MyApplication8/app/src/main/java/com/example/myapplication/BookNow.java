package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.textclassifier.TextClassificationManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DateFormat;


public class BookNow extends AppCompatActivity {
    private Button bookButton;
    private TextView tv;
    private EditText etx;

    private Button backButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_now);
        // -----------------------------------------


        bookButton = findViewById(R.id.bookButton);
        tv = findViewById(R.id.tv);
        etx = findViewById(R.id.etx);

        backButton = findViewById(R.id.back_but_page2);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookNow.this, IndexPage.class);
                startActivity(intent);
            }
        });
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(etx.getText());

            }
        });


    }
}
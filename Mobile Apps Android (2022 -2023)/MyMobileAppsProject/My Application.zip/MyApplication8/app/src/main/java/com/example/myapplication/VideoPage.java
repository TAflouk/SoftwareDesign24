package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class VideoPage extends AppCompatActivity {
    private Button videoBackBut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_page);
        videoBackBut = findViewById(R.id.videoBackBut);

        try {
            Bundle extras = getIntent().getExtras();
            String sentText = extras.getString("Send me");
            Toast.makeText(this, sentText, Toast.LENGTH_SHORT).show();
        } catch (RuntimeException e) {

            e.printStackTrace();
        }


        videoBackBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VideoPage.this, FindUsPage.class);
                startActivity(intent);
            }
        });

    }
}
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class OrderNowActivity extends AppCompatActivity {
    private Button backButIn;
    private Button menuButton;

    private RadioGroup radioChoiceGroup;
    private RadioButton choiceSelected;

    private int counter = 0;
    private ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_now);


        radioChoiceGroup = findViewById(R.id.radioGroupButtons);
        backButIn = findViewById(R.id.back);
        menuButton = findViewById(R.id.menu_but);


        backButIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OrderNowActivity.this, IndexPage.class);
                startActivity(intent);
            }
        });
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progressBar = findViewById(R.id.progressBar);

                Timer t  = new Timer();
                TimerTask tt = new TimerTask() {
                    @Override
                    public void run() {
                        counter++;
                        //   counter = counter + 5;
                        progressBar.setProgress(counter);

                        if(counter == 100) {
                            t.cancel();
                            Intent i = new Intent(OrderNowActivity.this, MenuPage.class);
                            startActivity(i);
                        }
                    }
                };

                t.schedule(tt,0,100);

                int setectedId = radioChoiceGroup.getCheckedRadioButtonId();
                choiceSelected = findViewById(setectedId);
                Toast.makeText(OrderNowActivity.this,choiceSelected.getText(), Toast.LENGTH_SHORT).show();

            }
        });



    }
}
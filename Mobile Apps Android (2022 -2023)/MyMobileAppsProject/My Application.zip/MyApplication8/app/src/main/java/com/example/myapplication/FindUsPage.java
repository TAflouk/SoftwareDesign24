package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class FindUsPage extends AppCompatActivity {
    private Button mapButton;
    private WebView webView;
    private Button phonebutton;
    private Button browserButton;
    private Button videoPage;

    private Button backButtonFindUsPage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_us_page);
        mapButton = findViewById(R.id.map_button);
        browserButton = findViewById(R.id.web_but);
        phonebutton = findViewById(R.id.phone_but);
        videoPage = findViewById(R.id.videoButton);

        backButtonFindUsPage = findViewById(R.id.back_but_finus_page);
        videoPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(FindUsPage.this, VideoPage.class);
                startActivity(intent);

                Intent i = new Intent(FindUsPage.this, VideoPage.class);
                String myText = "This msg came from find us page";
                i.putExtra("Send me", myText);
                startActivity(i);

            }
        });
        backButtonFindUsPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FindUsPage.this, IndexPage.class);
                startActivity(intent);
            }
        });
        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.setData(Uri.parse("geo:48.8584,2.2945"));
                startActivity(i);

            }
        });
        browserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://www.google.com");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);


            }
        });
        phonebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                i.setAction(Intent.ACTION_DIAL);
                i.setData(Uri.parse("tel:" + "1234567"));
                if (i.resolveActivity(getPackageManager()) != null)
                    startActivity(i);

            }
        });

    }
}